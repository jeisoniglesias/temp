<!-- BOOTSTRAP 4 SCRIPTS -->
<script src="/public/jquery.slim.min.js" crossorigin="anonymous"></script>
<script src="/public/popper.min.js" crossorigin="anonymous"></script>
<script src="/public/bootstrap.min.js" crossorigin="anonymous"></script>


</body>

</html>